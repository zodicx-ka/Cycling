<?php
/**
 * logout.php
 * Securely destroys the admin session and redirects to the homepage.
 */

session_start();

// Unset all session variables
$_SESSION = [];

// Destroy the session cookie
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Destroy the session on the server
session_destroy();

// Redirect to homepage with a logout confirmation
header('Location: index.html?logout=1');
exit();
?>

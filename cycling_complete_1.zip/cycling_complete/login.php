<?php
/**
 * login.php
 * Processes the admin login form.
 * Validates credentials against the `user` table and creates a secure session.
 */

session_start();

// ── Only accept POST requests ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: admin_login.html');
    exit();
}

// ── Collect and sanitise input ────────────────────────────────
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

// ── Basic presence check ──────────────────────────────────────
if ($username === '' || $password === '') {
    header('Location: admin_login.html?error=empty');
    exit();
}

// ── Check credentials against the database ────────────────────
include 'dbconnect.php';

try {
    // Use a prepared statement — never interpolate user input into SQL
    $stmt = $conn->prepare("SELECT id, username, password FROM `user` WHERE username = :username LIMIT 1");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch(); // Returns an array or false

    if ($user && $user['password'] === $password) {
        // ── Login successful ──────────────────────────────────
        // Regenerate session ID to prevent session fixation attacks
        session_regenerate_id(true);

        // Store the authenticated flag and admin's username in the session
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username']  = htmlspecialchars($user['username']);
        $_SESSION['admin_id']        = (int) $user['id'];
        $_SESSION['login_time']      = time(); // For potential timeout logic

        // Redirect to the admin menu
        header('Location: admin_menu.php');
        exit();

    } else {
        // ── Invalid credentials ───────────────────────────────
        // Briefly pause to slow down brute-force attempts
        sleep(1);
        header('Location: admin_login.html?error=invalid');
        exit();
    }

} catch (PDOException $e) {
    error_log('Cit-E Cycling DB Error (login.php): ' . $e->getMessage());
    header('Location: admin_login.html?error=db');
    exit();
}
?>

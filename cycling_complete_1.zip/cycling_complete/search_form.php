<?php
/**
 * search_form.php
 * Admin page — provides two search forms:
 *   1. Search participants by first name or surname
 *   2. Search clubs by club name
 *
 * Protected: admin login required.
 */

require 'auth_check.php';
$adminName = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Search — Cit-E Cycling Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="admin_menu.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link active" href="search_form.php"><i class="fas fa-search me-1"></i> Search</a></li>
                <li class="nav-item"><a class="nav-link" href="view_participants_edit_delete.php"><i class="fas fa-users me-1"></i> Participants</a></li>
                <li class="nav-item ms-lg-2"><span class="admin-badge d-none d-lg-inline"><i class="fas fa-user-shield me-1"></i> <?= $adminName ?></span></li>
                <li class="nav-item ms-lg-2"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="admin_menu.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Search</li>
            </ol>
        </nav>
        <h1><i class="fas fa-search me-2"></i>SEARCH PARTICIPANTS &amp; CLUBS</h1>
        <p class="mb-0" style="color:rgba(255,255,255,0.7);">
            Find participants by name, or look up a club and see all its members.
        </p>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">
        <div class="row g-4">

            <!-- ── Search Participants ─────────────────────────────── -->
            <div class="col-lg-6 fade-in-up">
                <div class="card h-100">
                    <div class="card-header-racing d-flex align-items-center gap-3">
                        <div class="icon"><i class="fas fa-user-search" style="font-size:0.9rem;"></i></div>
                        <h5>SEARCH PARTICIPANTS</h5>
                    </div>
                    <div class="card-body p-4">
                        <p class="text-muted mb-4" style="font-size:0.9rem;">
                            Enter a first name or surname to find matching participants.
                            Partial matches are supported — e.g. searching "Law" will find "Lawrence".
                        </p>

                        <form action="search_result.php" method="POST" id="participantSearchForm" novalidate>
                            <!-- Hidden field tells search_result.php which form was submitted -->
                            <input type="hidden" name="participant" value="1">

                            <div class="mb-4">
                                <label for="firstname" class="form-label">
                                    <i class="fas fa-user me-1 text-racing"></i>
                                    First Name or Surname <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" style="border:2px solid #e8ecf0;border-right:none;border-radius:8px 0 0 8px;background:#fdfdfd;">
                                        <i class="fas fa-search text-muted"></i>
                                    </span>
                                    <input type="text"
                                           class="form-control"
                                           id="firstname"
                                           name="firstname"
                                           placeholder="e.g. Lawrence or Upsale"
                                           maxlength="50"
                                           style="border-left:none;border-radius:0 8px 8px 0;"
                                           required>
                                    <div class="invalid-feedback">Please enter a name to search.</div>
                                </div>
                                <div class="form-text">
                                    Searches both first name and surname columns.
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-racing btn-lg">
                                    <i class="fas fa-search me-2"></i> Search Participants
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- ── Search Clubs ────────────────────────────────────── -->
            <div class="col-lg-6 fade-in-up">
                <div class="card h-100">
                    <div class="card-header-racing d-flex align-items-center gap-3">
                        <div class="icon"><i class="fas fa-users" style="font-size:0.9rem;"></i></div>
                        <h5>SEARCH CLUBS</h5>
                    </div>
                    <div class="card-body p-4">
                        <p class="text-muted mb-4" style="font-size:0.9rem;">
                            Enter a club name to view all its members, plus total and average
                            distance and power output across the club.
                        </p>

                        <form action="search_result.php" method="POST" id="clubSearchForm" novalidate>
                            <div class="mb-4">
                                <label for="club" class="form-label">
                                    <i class="fas fa-flag me-1 text-racing"></i>
                                    Club Name <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text" style="border:2px solid #e8ecf0;border-right:none;border-radius:8px 0 0 8px;background:#fdfdfd;">
                                        <i class="fas fa-search text-muted"></i>
                                    </span>
                                    <input type="text"
                                           class="form-control"
                                           id="club"
                                           name="club"
                                           placeholder="e.g. Roker Rollers"
                                           maxlength="100"
                                           style="border-left:none;border-radius:0 8px 8px 0;"
                                           required>
                                    <div class="invalid-feedback">Please enter a club name to search.</div>
                                </div>
                                <div class="form-text">
                                    Partial club names are supported — try "Byker" or "Durham".
                                </div>
                            </div>

                            <!-- Club hints -->
                            <div class="mb-4">
                                <p class="text-muted mb-2" style="font-size:0.8rem;text-transform:uppercase;letter-spacing:0.5px;font-weight:700;">
                                    <i class="fas fa-lightbulb me-1"></i> Known Clubs
                                </p>
                                <div class="d-flex flex-wrap gap-2">
                                    <?php
                                    $clubs = ['Roker Rollers', 'Byker Bikers', 'Middlesbrough Movers', 'Durham Dynamos'];
                                    foreach ($clubs as $c):
                                    ?>
                                    <button type="button"
                                            class="btn btn-sm btn-dark-outline"
                                            style="font-size:0.78rem;padding:0.25rem 0.65rem;"
                                            onclick="document.getElementById('club').value='<?= $c ?>'">
                                        <?= $c ?>
                                    </button>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-racing btn-lg">
                                    <i class="fas fa-search me-2"></i> Search Clubs
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

        <!-- ── Tips ── -->
        <div class="card mt-4">
            <div class="card-body p-3 d-flex flex-wrap align-items-center gap-3" style="font-size:0.85rem;color:var(--muted);">
                <i class="fas fa-info-circle text-racing fs-5"></i>
                <span>
                    <strong>Search Tips:</strong>
                    Searches are case-insensitive and match partial names.
                    Club searches also show total and average statistics for the entire club.
                </span>
                <a href="view_participants_edit_delete.php" class="btn btn-sm btn-dark-outline ms-auto">
                    <i class="fas fa-list me-1"></i> View All Participants
                </a>
            </div>
        </div>

    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Panel &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // ── Client-side validation for participant search ─────────
    document.getElementById('participantSearchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const field = document.getElementById('firstname');
        field.classList.remove('is-invalid');
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
        } else {
            this.submit();
        }
    });

    // ── Client-side validation for club search ────────────────
    document.getElementById('clubSearchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const field = document.getElementById('club');
        field.classList.remove('is-invalid');
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
        } else {
            this.submit();
        }
    });
</script>
</body>
</html>

<?php
/**
 * admin_menu.php
 * Admin landing page — only accessible when logged in.
 */

// ── Auth guard ────────────────────────────────────────────────
require 'auth_check.php';
$adminName = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard — Cit-E Cycling</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item">
                    <a class="nav-link active" href="admin_menu.php">
                        <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="search_form.php">
                        <i class="fas fa-search me-1"></i> Search
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_participants_edit_delete.php">
                        <i class="fas fa-users me-1"></i> Participants
                    </a>
                </li>
                <li class="nav-item ms-lg-2">
                    <span class="admin-badge d-none d-lg-inline">
                        <i class="fas fa-user-shield me-1"></i> <?= $adminName ?>
                    </span>
                </li>
                <li class="nav-item ms-lg-2">
                    <a class="nav-link" href="logout.php" onclick="return confirmLogout();">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div>
                <h1><i class="fas fa-tachometer-alt me-2"></i>ADMIN DASHBOARD</h1>
                <p class="mb-0" style="color:rgba(255,255,255,0.7);">
                    Welcome back, <strong style="color:white;"><?= $adminName ?></strong>.
                    Manage participants, scores, and clubs below.
                </p>
            </div>
            <a href="logout.php" class="btn btn-racing btn-sm" onclick="return confirmLogout();">
                <i class="fas fa-sign-out-alt me-1"></i> Logout
            </a>
        </div>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">

        <!-- Session info strip -->
        <div class="alert alert-info mb-4">
            <i class="fas fa-info-circle me-2"></i>
            You are logged in as <strong><?= $adminName ?></strong>.
            Your session is active — remember to <a href="logout.php" onclick="return confirmLogout();">logout</a> when finished.
        </div>

        <div class="text-center mb-5">
            <h2 class="display-font" style="font-size:2rem;color:var(--dark-2);">ADMIN TOOLS</h2>
            <p class="text-muted">Select an action below.</p>
        </div>

        <!-- Admin action cards -->
        <div class="row g-4">

            <!-- Search -->
            <div class="col-md-6 col-xl-3 fade-in-up">
                <a href="search_form.php" class="nav-card p-4 h-100">
                    <div class="card-icon blue">
                        <i class="fas fa-search"></i>
                    </div>
                    <h5>SEARCH</h5>
                    <p>Search participants by name or find clubs by club name with aggregated statistics.</p>
                    <div class="mt-3 d-flex justify-content-end">
                        <i class="fas fa-arrow-right arrow-icon fs-5"></i>
                    </div>
                </a>
            </div>

            <!-- View / Edit / Delete Participants -->
            <div class="col-md-6 col-xl-3 fade-in-up">
                <a href="view_participants_edit_delete.php" class="nav-card p-4 h-100">
                    <div class="card-icon red">
                        <i class="fas fa-users"></i>
                    </div>
                    <h5>VIEW PARTICIPANTS</h5>
                    <p>Browse all registered participants and access options to edit scores or delete entries.</p>
                    <div class="mt-3 d-flex justify-content-end">
                        <i class="fas fa-arrow-right arrow-icon fs-5"></i>
                    </div>
                </a>
            </div>

            <!-- Edit Scores -->
            <div class="col-md-6 col-xl-3 fade-in-up">
                <a href="view_participants_edit_delete.php" class="nav-card p-4 h-100">
                    <div class="card-icon gold">
                        <i class="fas fa-edit"></i>
                    </div>
                    <h5>EDIT SCORES</h5>
                    <p>Update power output and distance travelled for any participant via the participants list.</p>
                    <div class="mt-3 d-flex justify-content-end">
                        <i class="fas fa-arrow-right arrow-icon fs-5"></i>
                    </div>
                </a>
            </div>

            <!-- Delete Participants -->
            <div class="col-md-6 col-xl-3 fade-in-up">
                <a href="view_participants_edit_delete.php" class="nav-card p-4 h-100">
                    <div class="card-icon" style="background:rgba(231,76,60,0.12);color:var(--danger);">
                        <i class="fas fa-trash-alt"></i>
                    </div>
                    <h5>DELETE</h5>
                    <p>Remove participants from the competition database with a confirmation step to prevent mistakes.</p>
                    <div class="mt-3 d-flex justify-content-end">
                        <i class="fas fa-arrow-right arrow-icon fs-5"></i>
                    </div>
                </a>
            </div>

        </div>

        <!-- Quick nav -->
        <div class="card mt-5">
            <div class="card-header-racing d-flex align-items-center gap-3">
                <div class="icon"><i class="fas fa-bolt"></i></div>
                <h5>QUICK LINKS</h5>
            </div>
            <div class="card-body p-4">
                <div class="d-flex flex-wrap gap-3">
                    <a href="search_form.php" class="btn btn-racing">
                        <i class="fas fa-search me-2"></i>Search Participants &amp; Clubs
                    </a>
                    <a href="view_participants_edit_delete.php" class="btn btn-dark-outline">
                        <i class="fas fa-list me-2"></i>All Participants
                    </a>
                    <a href="index.html" class="btn btn-dark-outline">
                        <i class="fas fa-home me-2"></i>Public Homepage
                    </a>
                    <a href="logout.php" class="btn btn-outline-danger" onclick="return confirmLogout();">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>

    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Dashboard &mdash; Logged in as <?= $adminName ?> &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function confirmLogout() {
        return confirm('Are you sure you want to logout?');
    }
</script>
</body>
</html>

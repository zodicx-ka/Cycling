<?php
/**
 * edit_participant_form.php
 * Form fragment — included inside edit_participant.php (not a standalone page).
 * Displays the edit form pre-populated with the participant's current data.
 *
 * Expects: $participant (associative array from DB), $errors (array, may be empty)
 */
?>

<!-- ── Error messages (shown on re-render after failed validation) ── -->
<?php if (!empty($errors)): ?>
<div class="alert alert-danger mb-4">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <div>
        <strong>Please fix the following errors:</strong>
        <ul class="mt-2 mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
<?php endif; ?>

<!-- ── Participant Info Summary ── -->
<div class="alert alert-info mb-4">
    <i class="fas fa-user-circle me-2"></i>
    Editing scores for <strong><?= htmlspecialchars($participant['firstname'] . ' ' . $participant['surname']) ?></strong>
    <?php if (!empty($participant['club_name'])): ?>
        &mdash; <span class="badge-club"><?= htmlspecialchars($participant['club_name']) ?></span>
    <?php endif; ?>
</div>

<!-- ── Edit Form ── -->
<form action="edit_participant.php" method="POST" id="editForm" novalidate>

    <!-- Hidden field carries the participant ID -->
    <input type="hidden" name="id" value="<?= (int)$participant['id'] ?>">

    <div class="row g-4">

        <!-- Read-only: First Name -->
        <div class="col-md-6">
            <label class="form-label">
                <i class="fas fa-user me-1 text-racing"></i> First Name
                <span class="text-muted fw-normal ms-1" style="font-size:0.78rem;">(read-only)</span>
            </label>
            <input type="text"
                   class="form-control"
                   name="firstname"
                   value="<?= htmlspecialchars($participant['firstname']) ?>"
                   disabled
                   title="First name cannot be changed here">
        </div>

        <!-- Read-only: Surname -->
        <div class="col-md-6">
            <label class="form-label">
                <i class="fas fa-user me-1 text-racing"></i> Surname
                <span class="text-muted fw-normal ms-1" style="font-size:0.78rem;">(read-only)</span>
            </label>
            <input type="text"
                   class="form-control"
                   name="surname"
                   value="<?= htmlspecialchars($participant['surname']) ?>"
                   disabled
                   title="Surname cannot be changed here">
        </div>

        <!-- Read-only: Email -->
        <div class="col-12">
            <label class="form-label">
                <i class="fas fa-envelope me-1 text-racing"></i> Email
                <span class="text-muted fw-normal ms-1" style="font-size:0.78rem;">(read-only)</span>
            </label>
            <input type="email"
                   class="form-control"
                   value="<?= htmlspecialchars($participant['email']) ?>"
                   disabled>
        </div>

    </div>

    <div class="divider my-4"></div>
    <p class="text-muted" style="font-size:0.85rem;"><i class="fas fa-info-circle me-1"></i> Only <strong>Power Output</strong> and <strong>Distance</strong> can be updated.</p>

    <div class="row g-4">

        <!-- Editable: Power Output -->
        <div class="col-md-6">
            <label for="power_output" class="form-label">
                <i class="fas fa-bolt me-1 text-racing"></i> Power Output (Watts) <span class="text-danger">*</span>
            </label>
            <div class="input-group">
                <input type="number"
                       class="form-control <?= in_array('power', array_map(fn($e) => explode(' ', $e)[0], $errors ?? [])) ? 'is-invalid' : '' ?>"
                       id="power_output"
                       name="power_output"
                       value="<?= htmlspecialchars($formValues['power_output'] ?? $participant['power_output']) ?>"
                       min="0"
                       max="9999"
                       step="0.1"
                       placeholder="e.g. 250.5"
                       required>
                <span class="input-group-text">W</span>
                <div class="invalid-feedback">Please enter a valid power output (0–9999 watts).</div>
            </div>
            <div class="form-text">Enter a number between 0 and 9999. Decimals are allowed.</div>
        </div>

        <!-- Editable: Distance -->
        <div class="col-md-6">
            <label for="distance_travelled" class="form-label">
                <i class="fas fa-road me-1 text-racing"></i> Distance Travelled (km) <span class="text-danger">*</span>
            </label>
            <div class="input-group">
                <input type="number"
                       class="form-control"
                       id="distance_travelled"
                       name="distance_travelled"
                       value="<?= htmlspecialchars($formValues['distance_travelled'] ?? $participant['distance']) ?>"
                       min="0"
                       max="99999"
                       step="0.01"
                       placeholder="e.g. 42.5"
                       required>
                <span class="input-group-text">km</span>
                <div class="invalid-feedback">Please enter a valid distance (0–99999 km).</div>
            </div>
            <div class="form-text">Enter a number between 0 and 99999. Decimals are allowed.</div>
        </div>

    </div>

    <div class="divider my-4"></div>

    <!-- Action Buttons -->
    <div class="d-flex flex-wrap gap-3">
        <button type="submit" class="btn btn-racing btn-lg" id="updateBtn">
            <i class="fas fa-save me-2"></i> Update Scores
        </button>
        <a href="view_participants_edit_delete.php" class="btn btn-dark-outline btn-lg">
            <i class="fas fa-times me-2"></i> Cancel
        </a>
    </div>

</form>

<script>
    /**
     * Client-side validation for the edit form.
     * Server-side validation also runs in edit_participant.php.
     */
    document.getElementById('editForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const power    = document.getElementById('power_output');
        const distance = document.getElementById('distance_travelled');
        let valid = true;

        // Reset
        [power, distance].forEach(el => el.classList.remove('is-invalid', 'is-valid'));

        // Validate power output
        const powerVal = parseFloat(power.value);
        if (power.value === '' || isNaN(powerVal) || powerVal < 0 || powerVal > 9999) {
            power.classList.add('is-invalid');
            valid = false;
        } else {
            power.classList.add('is-valid');
        }

        // Validate distance
        const distVal = parseFloat(distance.value);
        if (distance.value === '' || isNaN(distVal) || distVal < 0 || distVal > 99999) {
            distance.classList.add('is-invalid');
            valid = false;
        } else {
            distance.classList.add('is-valid');
        }

        if (valid) {
            const btn = document.getElementById('updateBtn');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Updating...';
            this.submit();
        }
    });
</script>

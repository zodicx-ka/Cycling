<?php
/**
 * search_result.php
 * Handles results for both participant search and club search.
 *
 * POST with 'participant' => '1'  →  Search participant by firstname or surname
 * POST with 'club' field present  →  Search club by name (show members + stats)
 *
 * Protected: admin login required.
 */

require 'auth_check.php';
include 'dbconnect.php';

$adminName = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');

// ── Determine which search type was submitted ─────────────────
$isParticipantSearch = isset($_POST['participant']) && $_POST['participant'] === '1';
$isClubSearch        = isset($_POST['club']) && !$isParticipantSearch;

// ── Shared variables ──────────────────────────────────────────
$searchTerm   = '';
$results      = [];
$clubInfo     = null;
$clubStats    = null;
$error        = '';
$searchType   = '';

// ─────────────────────────────────────────────────────────────
// A: Participant Search — by firstname OR surname
// ─────────────────────────────────────────────────────────────
if ($isParticipantSearch) {
    $searchType = 'participant';
    $raw        = trim($_POST['firstname'] ?? '');
    $searchTerm = strip_tags($raw);

    if ($searchTerm === '') {
        $error = 'Please enter a name to search.';
    } elseif (strlen($searchTerm) < 1) {
        $error = 'Search term must be at least 1 character.';
    } else {
        try {
            // LIKE search on both firstname and surname — parameterised to prevent injection
            // The % wildcards allow partial matching (e.g. "Law" matches "Lawrence")
            $likeTerm = '%' . $searchTerm . '%';

            $stmt = $conn->prepare(
                "SELECT p.id, p.firstname, p.surname, p.email,
                        p.power_output, p.distance,
                        c.name AS club_name, c.location AS club_location
                 FROM participant p
                 LEFT JOIN club c ON p.club_id = c.id
                 WHERE p.firstname LIKE :term1
                    OR p.surname   LIKE :term2
                 ORDER BY p.surname ASC, p.firstname ASC"
            );
            $stmt->execute([
                ':term1' => $likeTerm,
                ':term2' => $likeTerm,
            ]);
            $results = $stmt->fetchAll();

        } catch (PDOException $e) {
            error_log('Cit-E Cycling DB Error (search_result.php participant): ' . $e->getMessage());
            $error = 'A database error occurred while searching. Please try again.';
        }
    }

// ─────────────────────────────────────────────────────────────
// B: Club Search — by club name; also computes aggregate stats
// ─────────────────────────────────────────────────────────────
} elseif ($isClubSearch) {
    $searchType = 'club';
    $raw        = trim($_POST['club'] ?? '');
    $searchTerm = strip_tags($raw);

    if ($searchTerm === '') {
        $error = 'Please enter a club name to search.';
    } else {
        try {
            // 1. Find the club(s) matching the search term
            $clubStmt = $conn->prepare(
                "SELECT id, name, location
                 FROM club
                 WHERE name LIKE :term
                 ORDER BY name ASC"
            );
            $clubStmt->execute([':term' => '%' . $searchTerm . '%']);
            $clubs = $clubStmt->fetchAll();

            if (empty($clubs)) {
                // No clubs matched — still show an empty-results message
                $results = [];
            } else {
                // Use the first matching club
                $clubInfo = $clubs[0];

                // 2. Fetch all participants for that club
                $memberStmt = $conn->prepare(
                    "SELECT p.id, p.firstname, p.surname, p.email,
                            p.power_output, p.distance
                     FROM participant p
                     WHERE p.club_id = :club_id
                     ORDER BY p.surname ASC, p.firstname ASC"
                );
                $memberStmt->execute([':club_id' => $clubInfo['id']]);
                $results = $memberStmt->fetchAll();

                // 3. Calculate aggregate statistics for the club
                if (!empty($results)) {
                    $totalDistance  = array_sum(array_column($results, 'distance'));
                    $totalPower     = array_sum(array_column($results, 'power_output'));
                    $memberCount    = count($results);
                    $avgDistance    = $totalDistance / $memberCount;
                    $avgPower       = $totalPower    / $memberCount;

                    $clubStats = [
                        'member_count'   => $memberCount,
                        'total_distance' => $totalDistance,
                        'total_power'    => $totalPower,
                        'avg_distance'   => $avgDistance,
                        'avg_power'      => $avgPower,
                    ];
                } else {
                    // Club exists but has no participants
                    $clubStats = [
                        'member_count'   => 0,
                        'total_distance' => 0,
                        'total_power'    => 0,
                        'avg_distance'   => 0,
                        'avg_power'      => 0,
                    ];
                }
            }

        } catch (PDOException $e) {
            error_log('Cit-E Cycling DB Error (search_result.php club): ' . $e->getMessage());
            $error = 'A database error occurred while searching. Please try again.';
        }
    }

} else {
    // Arrived here without a valid form submission
    header('Location: search_form.php');
    exit();
}

$resultCount = count($results);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results — Cit-E Cycling Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="admin_menu.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link active" href="search_form.php"><i class="fas fa-search me-1"></i> Search</a></li>
                <li class="nav-item"><a class="nav-link" href="view_participants_edit_delete.php"><i class="fas fa-users me-1"></i> Participants</a></li>
                <li class="nav-item ms-lg-2"><span class="admin-badge d-none d-lg-inline"><i class="fas fa-user-shield me-1"></i> <?= $adminName ?></span></li>
                <li class="nav-item ms-lg-2"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="admin_menu.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="search_form.php">Search</a></li>
                <li class="breadcrumb-item active">Results</li>
            </ol>
        </nav>
        <h1>
            <?php if ($searchType === 'participant'): ?>
                <i class="fas fa-user-search me-2"></i>PARTICIPANT SEARCH RESULTS
            <?php else: ?>
                <i class="fas fa-flag me-2"></i>CLUB SEARCH RESULTS
            <?php endif; ?>
        </h1>
        <p class="mb-0" style="color:rgba(255,255,255,0.7);">
            <?php if (!$error): ?>
                Searching for: <strong style="color:white;">"<?= htmlspecialchars($searchTerm) ?>"</strong>
                &mdash; <?= $resultCount ?> result<?= $resultCount !== 1 ? 's' : '' ?> found.
            <?php else: ?>
                Search could not be completed.
            <?php endif; ?>
        </p>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">

        <!-- ── Error state ── -->
        <?php if ($error): ?>
        <div class="alert alert-danger mb-4">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <a href="search_form.php" class="btn btn-racing">
            <i class="fas fa-arrow-left me-2"></i> Back to Search
        </a>

        <?php elseif ($searchType === 'participant'): ?>
        <!-- ══════════════════════════════════════════════════════
             PARTICIPANT SEARCH RESULTS
             ══════════════════════════════════════════════════════ -->

        <!-- Toolbar -->
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
            <span class="text-muted" style="font-size:0.9rem;">
                <i class="fas fa-info-circle me-1"></i>
                <?= $resultCount ?> participant<?= $resultCount !== 1 ? 's' : '' ?> matched
                "<strong><?= htmlspecialchars($searchTerm) ?></strong>"
            </span>
            <a href="search_form.php" class="btn btn-dark-outline btn-sm">
                <i class="fas fa-search me-1"></i> New Search
            </a>
        </div>

        <?php if (empty($results)): ?>
        <!-- No results -->
        <div class="card">
            <div class="card-body text-center p-5">
                <div style="font-size:3rem;margin-bottom:1rem;">🔍</div>
                <h4 class="display-font" style="font-size:1.5rem;color:var(--dark-2);">NO PARTICIPANTS FOUND</h4>
                <p class="text-muted mb-4">
                    No participant with the name "<strong><?= htmlspecialchars($searchTerm) ?></strong>" was found.<br>
                    Try a different spelling or a shorter search term.
                </p>
                <a href="search_form.php" class="btn btn-racing">
                    <i class="fas fa-search me-2"></i> Try Again
                </a>
            </div>
        </div>

        <?php else: ?>
        <!-- Results table -->
        <div class="card">
            <div class="card-header-racing d-flex align-items-center gap-3">
                <div class="icon"><i class="fas fa-users"></i></div>
                <h5>MATCHING PARTICIPANTS</h5>
                <span class="ms-auto badge bg-secondary"><?= $resultCount ?> found</span>
            </div>
            <div class="table-responsive">
                <table class="table table-cycling mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Club</th>
                            <th>Location</th>
                            <th>Power (W)</th>
                            <th>Distance (km)</th>
                            <th style="text-align:center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $p): ?>
                        <tr>
                            <td><span class="text-muted" style="font-size:0.8rem;"><?= (int)$p['id'] ?></span></td>
                            <td>
                                <div style="font-weight:700;">
                                    <?= htmlspecialchars($p['firstname'] . ' ' . $p['surname']) ?>
                                </div>
                            </td>
                            <td>
                                <a href="mailto:<?= htmlspecialchars($p['email']) ?>" style="font-size:0.85rem;color:var(--muted);">
                                    <?= htmlspecialchars($p['email']) ?>
                                </a>
                            </td>
                            <td>
                                <?php if ($p['club_name']): ?>
                                    <span class="badge-club"><?= htmlspecialchars($p['club_name']) ?></span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="text-muted" style="font-size:0.85rem;">
                                    <?= htmlspecialchars($p['club_location'] ?? '—') ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge-stat"><?= number_format((float)$p['power_output'], 1) ?> W</span>
                            </td>
                            <td>
                                <span class="badge-stat" style="background:linear-gradient(135deg,#2ecc71,#27ae60);">
                                    <?= number_format((float)$p['distance'], 2) ?> km
                                </span>
                            </td>
                            <td style="text-align:center;white-space:nowrap;">
                                <a href="edit_participant.php?id=<?= (int)$p['id'] ?>"
                                   class="btn btn-sm btn-warning btn-sm-racing me-1">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                                <a href="delete.php?id=<?= (int)$p['id'] ?>"
                                   class="btn btn-sm btn-danger btn-sm-racing"
                                   onclick="return confirm('Delete <?= htmlspecialchars($p['firstname'] . ' ' . $p['surname'], ENT_QUOTES) ?>?\nThis cannot be undone.')">
                                    <i class="fas fa-trash me-1"></i> Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>


        <?php elseif ($searchType === 'club'): ?>
        <!-- ══════════════════════════════════════════════════════
             CLUB SEARCH RESULTS
             ══════════════════════════════════════════════════════ -->

        <!-- Toolbar -->
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
            <span class="text-muted" style="font-size:0.9rem;">
                <i class="fas fa-info-circle me-1"></i>
                Searching clubs matching "<strong><?= htmlspecialchars($searchTerm) ?></strong>"
            </span>
            <a href="search_form.php" class="btn btn-dark-outline btn-sm">
                <i class="fas fa-search me-1"></i> New Search
            </a>
        </div>

        <?php if (!$clubInfo): ?>
        <!-- No club found -->
        <div class="card">
            <div class="card-body text-center p-5">
                <div style="font-size:3rem;margin-bottom:1rem;">🏁</div>
                <h4 class="display-font" style="font-size:1.5rem;color:var(--dark-2);">NO CLUB FOUND</h4>
                <p class="text-muted mb-4">
                    No club matching "<strong><?= htmlspecialchars($searchTerm) ?></strong>" was found.<br>
                    Try: Roker Rollers, Byker Bikers, Middlesbrough Movers, or Durham Dynamos.
                </p>
                <a href="search_form.php" class="btn btn-racing">
                    <i class="fas fa-search me-2"></i> Try Again
                </a>
            </div>
        </div>

        <?php else: ?>

        <!-- ── Club Info Card ── -->
        <div class="card mb-4 result-card">
            <div class="result-header d-flex align-items-center gap-3">
                <div style="width:50px;height:50px;background:var(--primary);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0;">
                    🏆
                </div>
                <div>
                    <h3 class="display-font mb-0" style="font-size:1.8rem;">
                        <?= htmlspecialchars($clubInfo['name']) ?>
                    </h3>
                    <p class="mb-0" style="color:rgba(255,255,255,0.7);font-size:0.9rem;">
                        <i class="fas fa-map-marker-alt me-1"></i>
                        <?= htmlspecialchars($clubInfo['location']) ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- ── Club Statistics ── -->
        <?php if ($clubStats): ?>
        <div class="row g-3 mb-4">
            <div class="col-6 col-md-3">
                <div class="stat-box">
                    <div class="stat-label"><i class="fas fa-users me-1"></i> Members</div>
                    <div class="stat-value"><?= $clubStats['member_count'] ?></div>
                    <small class="text-muted">Registered riders</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="stat-box gold">
                    <div class="stat-label"><i class="fas fa-road me-1"></i> Total Distance</div>
                    <div class="stat-value"><?= number_format($clubStats['total_distance'], 1) ?></div>
                    <small class="text-muted">km combined</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="stat-box green">
                    <div class="stat-label"><i class="fas fa-bolt me-1"></i> Total Power</div>
                    <div class="stat-value"><?= number_format($clubStats['total_power'], 0) ?></div>
                    <small class="text-muted">watts combined</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="stat-box blue">
                    <div class="stat-label"><i class="fas fa-chart-bar me-1"></i> Avg Distance</div>
                    <div class="stat-value"><?= number_format($clubStats['avg_distance'], 1) ?></div>
                    <small class="text-muted">km per rider</small>
                </div>
            </div>
        </div>

        <!-- Average power as a separate highlighted strip -->
        <div class="alert alert-info mb-4 d-flex align-items-center gap-3">
            <i class="fas fa-tachometer-alt fs-4 text-racing"></i>
            <div>
                <strong>Average Power Output:</strong>
                <?= number_format($clubStats['avg_power'], 1) ?> W per rider
                &nbsp;|&nbsp;
                <strong>Average Distance:</strong>
                <?= number_format($clubStats['avg_distance'], 2) ?> km per rider
            </div>
        </div>
        <?php endif; ?>

        <!-- ── Club Members Table ── -->
        <?php if (empty($results)): ?>
        <div class="alert alert-warning">
            <i class="fas fa-info-circle me-2"></i>
            <strong><?= htmlspecialchars($clubInfo['name']) ?></strong> currently has no participants registered.
        </div>

        <?php else: ?>
        <div class="card">
            <div class="card-header-racing d-flex align-items-center gap-3">
                <div class="icon"><i class="fas fa-list"></i></div>
                <h5>CLUB MEMBERS</h5>
                <span class="ms-auto badge bg-secondary"><?= $resultCount ?> member<?= $resultCount !== 1 ? 's' : '' ?></span>
            </div>
            <div class="table-responsive">
                <table class="table table-cycling mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Power Output (W)</th>
                            <th>Distance (km)</th>
                            <th style="text-align:center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $member): ?>
                        <tr>
                            <td><span class="text-muted" style="font-size:0.8rem;"><?= (int)$member['id'] ?></span></td>
                            <td>
                                <div style="font-weight:700;">
                                    <?= htmlspecialchars($member['firstname'] . ' ' . $member['surname']) ?>
                                </div>
                            </td>
                            <td>
                                <a href="mailto:<?= htmlspecialchars($member['email']) ?>"
                                   style="font-size:0.85rem;color:var(--muted);">
                                    <?= htmlspecialchars($member['email']) ?>
                                </a>
                            </td>
                            <td>
                                <span class="badge-stat"><?= number_format((float)$member['power_output'], 1) ?> W</span>
                            </td>
                            <td>
                                <span class="badge-stat" style="background:linear-gradient(135deg,#2ecc71,#27ae60);">
                                    <?= number_format((float)$member['distance'], 2) ?> km
                                </span>
                            </td>
                            <td style="text-align:center;white-space:nowrap;">
                                <a href="edit_participant.php?id=<?= (int)$member['id'] ?>"
                                   class="btn btn-sm btn-warning btn-sm-racing me-1">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                                <a href="delete.php?id=<?= (int)$member['id'] ?>"
                                   class="btn btn-sm btn-danger btn-sm-racing"
                                   onclick="return confirm('Delete <?= htmlspecialchars($member['firstname'] . ' ' . $member['surname'], ENT_QUOTES) ?>?')">
                                    <i class="fas fa-trash me-1"></i> Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <!-- ── Totals Footer Row ── -->
                    <?php if ($clubStats && $clubStats['member_count'] > 0): ?>
                    <tfoot>
                        <tr style="background:#f8f9fa;font-weight:700;border-top:2px solid #dee2e6;">
                            <td colspan="3" style="padding:0.85rem;font-size:0.9rem;color:var(--dark-2);">
                                <i class="fas fa-calculator me-1 text-racing"></i>
                                CLUB TOTALS &amp; AVERAGES
                            </td>
                            <td style="padding:0.85rem;">
                                <div style="font-size:0.82rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.5px;">Total</div>
                                <strong><?= number_format($clubStats['total_power'], 1) ?> W</strong>
                                <div style="font-size:0.78rem;color:var(--muted);margin-top:2px;">
                                    Avg: <?= number_format($clubStats['avg_power'], 1) ?> W
                                </div>
                            </td>
                            <td style="padding:0.85rem;">
                                <div style="font-size:0.82rem;color:var(--muted);text-transform:uppercase;letter-spacing:0.5px;">Total</div>
                                <strong><?= number_format($clubStats['total_distance'], 2) ?> km</strong>
                                <div style="font-size:0.78rem;color:var(--muted);margin-top:2px;">
                                    Avg: <?= number_format($clubStats['avg_distance'], 2) ?> km
                                </div>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; // club found ?>

        <?php endif; // searchType ?>

        <!-- ── Back Button ── -->
        <?php if (!$error): ?>
        <div class="mt-4">
            <a href="search_form.php" class="btn btn-dark-outline">
                <i class="fas fa-search me-2"></i> Back to Search
            </a>
            <a href="admin_menu.php" class="btn btn-dark-outline ms-2">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
        </div>
        <?php endif; ?>

    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Panel &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

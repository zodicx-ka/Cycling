<?php
/**
 * auth_check.php
 * Included at the top of every admin-only page.
 * Starts the session and redirects unauthenticated users to the login page.
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the admin flag is set and is explicitly true
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page — no peeking!
    header('Location: admin_login.html');
    exit();
}
?>

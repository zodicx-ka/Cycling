<?php
/**
 * delete.php
 * Admin page — shows a confirmation screen then deletes a participant.
 * GET  ?id=N  → shows the confirmation page
 * POST        → performs the DELETE
 *
 * Protected: admin login required.
 */

// ── Auth guard ────────────────────────────────────────────────
require 'auth_check.php';

// ── Database connection ───────────────────────────────────────
include 'dbconnect.php';

$adminName   = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');
$participant = null;
$error       = '';
$deleted     = false;

// ─────────────────────────────────────────────────────────────
// POST: Perform the actual delete after confirmation
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

    if (!$id || $id < 1) {
        $error = 'Invalid participant ID. Cannot delete.';
    } else {
        try {
            // First, fetch the participant so we can show their name in the success msg
            $selectStmt = $conn->prepare("SELECT firstname, surname FROM participant WHERE id = :id LIMIT 1");
            $selectStmt->execute([':id' => $id]);
            $toDelete = $selectStmt->fetch();

            if (!$toDelete) {
                $error = 'Participant not found — they may have already been deleted.';
            } else {
                // Execute DELETE — prepared statement prevents SQL injection
                $deleteStmt = $conn->prepare("DELETE FROM participant WHERE id = :id");
                $deleteStmt->execute([':id' => $id]);

                $deleted     = true;
                $participant = $toDelete; // keep name for success message
            }

        } catch (PDOException $e) {
            error_log('Cit-E Cycling DB Error (delete.php POST): ' . $e->getMessage());
            $error = 'A database error occurred. Please try again.';
        }
    }

// ─────────────────────────────────────────────────────────────
// GET: Show confirmation page before deleting
// ─────────────────────────────────────────────────────────────
} else {

    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if (!$id || $id < 1) {
        header('Location: view_participants_edit_delete.php');
        exit();
    }

    try {
        // Fetch full participant info to display on the confirmation page
        $stmt = $conn->prepare(
            "SELECT p.id, p.firstname, p.surname, p.email, p.power_output, p.distance, c.name AS club_name
             FROM participant p
             LEFT JOIN club c ON p.club_id = c.id
             WHERE p.id = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $participant = $stmt->fetch();

        if (!$participant) {
            header('Location: view_participants_edit_delete.php?error=notfound');
            exit();
        }

    } catch (PDOException $e) {
        error_log('Cit-E Cycling DB Error (delete.php GET): ' . $e->getMessage());
        $error = 'Unable to load participant data.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Participant — Cit-E Cycling Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="admin_menu.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="view_participants_edit_delete.php"><i class="fas fa-users me-1"></i> Participants</a></li>
                <li class="nav-item ms-lg-2"><span class="admin-badge d-none d-lg-inline"><i class="fas fa-user-shield me-1"></i> <?= $adminName ?></span></li>
                <li class="nav-item ms-lg-2"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="admin_menu.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="view_participants_edit_delete.php">Participants</a></li>
                <li class="breadcrumb-item active">Delete</li>
            </ol>
        </nav>
        <h1><i class="fas fa-trash-alt me-2"></i>DELETE PARTICIPANT</h1>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-xl-6">

                <?php if ($deleted): ?>
                <!-- ── Successful deletion ── -->
                <div class="confirm-box text-center">
                    <div style="width:90px;height:90px;background:rgba(39,174,96,0.12);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;font-size:2.5rem;color:var(--success);">
                        <i class="fas fa-check"></i>
                    </div>
                    <h3 class="display-font" style="font-size:1.8rem;">PARTICIPANT DELETED</h3>
                    <p class="text-muted mb-4">
                        <strong><?= htmlspecialchars($participant['firstname'] . ' ' . $participant['surname']) ?></strong>
                        has been permanently removed from the competition database.
                    </p>
                    <div class="alert alert-warning" style="text-align:left;">
                        <i class="fas fa-info-circle me-2"></i>
                        This action is <strong>irreversible</strong>. The participant's data has been deleted.
                    </div>
                    <div class="d-grid gap-2 mt-4">
                        <a href="view_participants_edit_delete.php" class="btn btn-racing btn-lg">
                            <i class="fas fa-list me-2"></i> Back to All Participants
                        </a>
                        <a href="admin_menu.php" class="btn btn-dark-outline">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </div>
                </div>

                <?php elseif ($error): ?>
                <!-- ── Error state ── -->
                <div class="alert alert-danger mb-4">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
                <a href="view_participants_edit_delete.php" class="btn btn-dark-outline">
                    <i class="fas fa-arrow-left me-2"></i> Back to Participants
                </a>

                <?php elseif ($participant): ?>
                <!-- ── Confirmation page ── -->
                <div class="confirm-box">

                    <!-- Warning icon -->
                    <div class="danger-icon">⚠️</div>

                    <h3 class="display-font mb-2" style="font-size:1.7rem;">CONFIRM DELETION</h3>
                    <p class="text-muted mb-4">
                        You are about to permanently delete this participant.<br>
                        <strong>This action cannot be undone.</strong>
                    </p>

                    <!-- Participant summary -->
                    <div class="card mb-4 text-start" style="border:2px solid rgba(231,76,60,0.25);">
                        <div class="card-body">
                            <table class="table table-sm mb-0" style="font-size:0.9rem;">
                                <tr>
                                    <th class="text-muted" style="width:40%;border:none;">Name</th>
                                    <td style="border:none; font-weight:700;">
                                        <?= htmlspecialchars($participant['firstname'] . ' ' . $participant['surname']) ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-muted" style="border:none;">Email</th>
                                    <td style="border:none;"><?= htmlspecialchars($participant['email']) ?></td>
                                </tr>
                                <tr>
                                    <th class="text-muted" style="border:none;">Club</th>
                                    <td style="border:none;">
                                        <?= $participant['club_name'] ? htmlspecialchars($participant['club_name']) : '—' ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-muted" style="border:none;">Power Output</th>
                                    <td style="border:none;"><?= number_format((float)$participant['power_output'], 1) ?> W</td>
                                </tr>
                                <tr>
                                    <th class="text-muted" style="border:none;">Distance</th>
                                    <td style="border:none;"><?= number_format((float)$participant['distance'], 2) ?> km</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Confirmation form — POST to this same page to delete -->
                    <form action="delete.php" method="POST" id="deleteForm">
                        <input type="hidden" name="id" value="<?= (int)$participant['id'] ?>">

                        <div class="d-grid gap-3">
                            <!-- Confirm delete button -->
                            <button type="submit" class="btn btn-danger btn-lg" id="confirmDeleteBtn"
                                    onclick="return doubleConfirm('<?= htmlspecialchars($participant['firstname'] . ' ' . $participant['surname'], ENT_QUOTES) ?>')">
                                <i class="fas fa-trash-alt me-2"></i>
                                Yes, Delete This Participant
                            </button>
                            <!-- Cancel — go back safely -->
                            <a href="view_participants_edit_delete.php" class="btn btn-racing btn-lg">
                                <i class="fas fa-times me-2"></i> Cancel — Keep This Participant
                            </a>
                        </div>
                    </form>

                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Panel &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    /**
     * A second JS confirmation prompt as an extra safety net.
     * The primary guard is the confirmation page itself.
     */
    function doubleConfirm(name) {
        return confirm(
            `FINAL WARNING\n\nAre you absolutely sure you want to delete "${name}"?\n` +
            `This cannot be undone.`
        );
    }
</script>
</body>
</html>

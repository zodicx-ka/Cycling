<?php
/**
 * register.php
 * Handles the interest registration form submission.
 * Validates all input server-side and inserts into the `interest` table.
 */

// ── Helpers ───────────────────────────────────────────────────
/**
 * Sanitise a plain text input: trim whitespace and strip HTML/PHP tags.
 * Output is still run through htmlspecialchars() before being echoed.
 */
function sanitise(string $value): string {
    return trim(strip_tags($value));
}

// ── Only process POST requests ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register_form.html');
    exit();
}

// ── Collect and sanitise inputs ───────────────────────────────
$firstname = sanitise($_POST['firstname'] ?? '');
$surname   = sanitise($_POST['surname']   ?? '');
$email     = sanitise($_POST['email']     ?? '');
$termsRaw  = $_POST['terms'] ?? '';          // checkbox value "yes" or empty

// ── Server-side validation ────────────────────────────────────
$errors = [];

// First name
if ($firstname === '') {
    $errors[] = 'First name is required.';
} elseif (strlen($firstname) < 2 || strlen($firstname) > 50) {
    $errors[] = 'First name must be between 2 and 50 characters.';
} elseif (!preg_match("/^[a-zA-Z\s'\-]+$/", $firstname)) {
    $errors[] = 'First name may only contain letters, spaces, hyphens, and apostrophes.';
}

// Surname
if ($surname === '') {
    $errors[] = 'Surname is required.';
} elseif (strlen($surname) < 2 || strlen($surname) > 50) {
    $errors[] = 'Surname must be between 2 and 50 characters.';
} elseif (!preg_match("/^[a-zA-Z\s'\-]+$/", $surname)) {
    $errors[] = 'Surname may only contain letters, spaces, hyphens, and apostrophes.';
}

// Email
if ($email === '') {
    $errors[] = 'Email address is required.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address.';
} elseif (strlen($email) > 100) {
    $errors[] = 'Email address is too long (maximum 100 characters).';
}

// Terms & Conditions
$termsAccepted = ($termsRaw === 'yes') ? 1 : 0;
if (!$termsAccepted) {
    $errors[] = 'You must accept the terms and conditions to register.';
}

// ── If validation failed, show errors ─────────────────────────
if (!empty($errors)) {
    // Build error list HTML
    $errorHtml = implode('', array_map(fn($e) => "<li>$e</li>", $errors));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Error — Cit-E Cycling</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
    </div>
</nav>
<div class="page-header">
    <div class="container">
        <h1><i class="fas fa-exclamation-triangle me-2"></i>REGISTRATION ERROR</h1>
    </div>
</div>
<main class="main-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-xl-6">
                <div class="alert alert-danger mb-4">
                    <i class="fas fa-times-circle fa-lg me-2"></i>
                    <div>
                        <strong>Please fix the following errors:</strong>
                        <ul class="mt-2 mb-0"><?= $errorHtml ?></ul>
                    </div>
                </div>
                <!-- Re-render form with previous values preserved -->
                <div class="card">
                    <div class="card-header-racing d-flex align-items-center gap-3">
                        <div class="icon"><i class="fas fa-redo"></i></div>
                        <h5>CORRECT YOUR DETAILS</h5>
                    </div>
                    <div class="card-body p-4">
                        <form action="register.php" method="POST">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-user me-1 text-racing"></i> First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= ($firstname==='')?'is-invalid':'' ?>" name="firstname"
                                       value="<?= htmlspecialchars($firstname) ?>" maxlength="50" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-user me-1 text-racing"></i> Surname <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= ($surname==='')?'is-invalid':'' ?>" name="surname"
                                       value="<?= htmlspecialchars($surname) ?>" maxlength="50" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-envelope me-1 text-racing"></i> Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control <?= ($email==='')?'is-invalid':'' ?>" name="email"
                                       value="<?= htmlspecialchars($email) ?>" maxlength="100" required>
                            </div>
                            <div class="divider"></div>
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input <?= (!$termsAccepted)?'is-invalid':'' ?>" type="checkbox" name="terms" value="yes" id="terms">
                                    <label class="form-check-label" for="terms" style="text-transform:none;letter-spacing:0;font-weight:600;">
                                        I accept the Terms and Conditions <span class="text-danger">*</span>
                                    </label>
                                </div>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-racing btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i> Try Again
                                </button>
                                <a href="register_form.html" class="btn btn-dark-outline">
                                    <i class="fas fa-arrow-left me-2"></i> Back to Form
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer><strong>Cit-E Cycling</strong> &mdash; National Cycling Competition Portal &mdash; &copy; 2024</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
    exit();
}

// ── Insert into database ──────────────────────────────────────
include 'dbconnect.php';

$success = false;
$dbError = '';

try {
    // Prepared statement prevents SQL injection completely
    $stmt = $conn->prepare(
        "INSERT INTO `interest` (firstname, surname, email, terms)
         VALUES (:firstname, :surname, :email, :terms)"
    );

    $stmt->execute([
        ':firstname' => $firstname,
        ':surname'   => $surname,
        ':email'     => $email,
        ':terms'     => $termsAccepted,
    ]);

    $success = true;

} catch (PDOException $e) {
    // Log the full error internally; show only a safe message to the user
    error_log('Cit-E Cycling DB Error (register.php): ' . $e->getMessage());
    $dbError = 'A database error occurred. Please try again later.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration <?= $success ? 'Successful' : 'Failed' ?> — Cit-E Cycling</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
    </div>
</nav>
<div class="page-header">
    <div class="container">
        <h1>
            <?php if ($success): ?>
                <i class="fas fa-check-circle me-2"></i>REGISTRATION SUCCESSFUL
            <?php else: ?>
                <i class="fas fa-times-circle me-2"></i>REGISTRATION FAILED
            <?php endif; ?>
        </h1>
    </div>
</div>
<main class="main-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <?php if ($success): ?>
                    <!-- Success state -->
                    <div class="card text-center">
                        <div class="card-body p-5">
                            <div style="width:90px;height:90px;background:rgba(39,174,96,0.12);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;font-size:2.5rem;color:var(--success);">
                                <i class="fas fa-check"></i>
                            </div>
                            <h3 class="display-font" style="font-size:1.8rem;">INTEREST REGISTERED!</h3>
                            <p class="text-muted mb-1">Thank you, <strong><?= htmlspecialchars($firstname . ' ' . $surname) ?></strong>!</p>
                            <p class="text-muted mb-4">
                                Your interest has been recorded. We'll be in touch at
                                <strong><?= htmlspecialchars($email) ?></strong> when events are announced.
                            </p>
                            <div class="alert alert-success">
                                <i class="fas fa-info-circle me-2"></i>
                                Keep an eye on your inbox for upcoming Cit-E Cycling events!
                            </div>
                            <a href="index.html" class="btn btn-racing btn-lg mt-3">
                                <i class="fas fa-home me-2"></i> Return to Homepage
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Failure state -->
                    <div class="alert alert-danger mb-4">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?= htmlspecialchars($dbError) ?>
                    </div>
                    <div class="d-grid gap-2">
                        <a href="register_form.html" class="btn btn-racing btn-lg">
                            <i class="fas fa-redo me-2"></i> Try Again
                        </a>
                        <a href="index.html" class="btn btn-dark-outline">
                            <i class="fas fa-home me-2"></i> Home
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<footer><strong>Cit-E Cycling</strong> &mdash; National Cycling Competition Portal &mdash; &copy; 2024</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

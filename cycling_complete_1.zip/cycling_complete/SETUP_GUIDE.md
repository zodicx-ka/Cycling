# Cit-E Cycling — Setup & Deployment Guide
## CET138 Assignment 2

---

## 📁 Project Files

| File | Purpose |
|---|---|
| `index.html` | Public homepage |
| `register_form.html` | Registration interest form |
| `register.php` | Handles registration form submission |
| `admin_login.html` | Admin login page |
| `login.php` | Processes login, creates session |
| `logout.php` | Destroys session and redirects |
| `admin_menu.php` | Admin dashboard (session-protected) |
| `view_participants_edit_delete.php` | View all participants (session-protected) |
| `edit_participant.php` | Edit participant scores (session-protected) |
| `edit_participant_form.php` | Form fragment included by edit_participant.php |
| `delete.php` | Delete participant with confirmation (session-protected) |
| `search_form.php` | Search form — participants and clubs (session-protected) |
| `search_result.php` | Search results display (session-protected) |
| `dbconnect.php` | Database credentials + PDO connection |
| `auth_check.php` | Session guard — included by all admin pages |
| `style.css` | Custom Bootstrap theme + all styling |
| `cycling.sql` | Database schema + seed data |

---

## 🚀 Local Setup with XAMPP

### Step 1 — Install XAMPP
Download XAMPP from [https://www.apachefriends.org](https://www.apachefriends.org) and install it.
- Start **Apache** and **MySQL** from the XAMPP Control Panel.

### Step 2 — Copy Project Files
Copy the entire `cycling` folder into your XAMPP web root:
```
C:\xampp\htdocs\cycling\
```
On macOS/Linux: `/Applications/XAMPP/htdocs/cycling/` or `/opt/lampp/htdocs/cycling/`

### Step 3 — Create the Database

1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Click **New** in the left sidebar.
3. Name the database `cycling` and click **Create**.
4. Click the `cycling` database, then click the **Import** tab.
5. Click **Choose File**, select `cycling.sql`, then click **Go**.

This creates four tables (`club`, `interest`, `participant`, `user`) with all sample data.

### Step 4 — Configure the Database Connection

Open `dbconnect.php` and verify these values match your XAMPP setup:

```php
$servername = "localhost";
$username   = "root";    // XAMPP default
$password   = "";        // XAMPP default (empty)
$database   = "cycling";
```

> **Note:** If you set a MySQL root password in XAMPP, enter it in `$password`.

### Step 5 — Open the Website

Navigate to: `http://localhost/cycling/`

You should see the Cit-E Cycling homepage.

---

## 🔑 Admin Credentials

| Field | Value |
|---|---|
| Username | `admin` |
| Password | `password123` |

Access the admin area at: `http://localhost/cycling/admin_login.html`

---

## 🧪 Testing Checklist

### Public Features
- [ ] Visit `index.html` — homepage loads correctly
- [ ] Click **Register Interest** — form loads
- [ ] Submit the registration form with valid data — success message shown
- [ ] Try submitting with empty fields — validation errors shown
- [ ] Try submitting with an invalid email — validation error shown
- [ ] Try submitting without ticking Terms — validation error shown

### Admin Login
- [ ] Visit `admin_login.html` — login page loads
- [ ] Try wrong credentials — error message shown
- [ ] Try empty fields — error message shown
- [ ] Login with `admin` / `password123` — redirected to admin dashboard
- [ ] Try to access `admin_menu.php` directly without logging in — redirected to login

### Admin — View & Edit Participants
- [ ] Visit **All Participants** — table shows all 30 participants
- [ ] Use the filter box — results narrow as you type
- [ ] Click **Edit** on a participant — edit form loads with their data
- [ ] Try updating with a negative power output — validation error
- [ ] Try updating with non-numeric text — validation error
- [ ] Update with valid values — success message shown, values saved

### Admin — Delete Participants
- [ ] Click **Delete** on the participants list — JS confirmation appears
- [ ] Confirm the deletion — full confirmation page shown
- [ ] Click **Cancel** — returned safely to participants list
- [ ] Confirm the second prompt — participant is deleted

### Admin — Search
- [ ] Search for a participant by first name — results shown
- [ ] Search for a participant by surname — results shown
- [ ] Search for a partial name (e.g. "Law") — matches shown
- [ ] Search for a non-existent name — "No results" message shown
- [ ] Search for a club (e.g. "Roker") — club info + members shown
- [ ] Verify club totals and averages display correctly
- [ ] Search for a non-existent club — "No club found" message shown

### Logout
- [ ] Click **Logout** — confirmation shown
- [ ] Confirm — session destroyed, redirected to homepage
- [ ] Try to visit `admin_menu.php` — redirected to login

---

## 🔐 Security Features Implemented

| Feature | How |
|---|---|
| SQL Injection Prevention | PDO prepared statements throughout |
| XSS Prevention | `htmlspecialchars()` on all output |
| Session Fixation Prevention | `session_regenerate_id(true)` on login |
| Admin Route Protection | `auth_check.php` on all admin pages |
| Input Validation | Server-side + client-side on all forms |
| Error Exposure | Generic user messages; full errors logged via `error_log()` |
| Brute-force Mitigation | `sleep(1)` on failed login attempts |
| Negative/Non-numeric Prevention | Range + `is_numeric()` checks on score updates |

---

## 🌐 Deployment on UoS Webspace

1. Upload all files via **FileZilla** or your institution's file manager.
2. Update `dbconnect.php` with your UoS database credentials.
3. Ensure PHP 7.4+ and PDO MySQL extension are available.
4. Import `cycling.sql` via the institution's phpMyAdmin.

---

## 🗃️ Database Structure

```
cycling (database)
├── club         (id, name, location)
├── interest     (id, firstname, surname, email, terms)
├── participant  (id, firstname, surname, email, power_output, distance, club_id)
└── user         (id, username, password)
```

> The database structure has **not** been modified from the original.

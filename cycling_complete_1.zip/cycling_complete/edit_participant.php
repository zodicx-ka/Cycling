<?php
/**
 * edit_participant.php
 * Admin page to edit a participant's power output and distance.
 * GET  ?id=N → shows the edit form pre-filled with current data
 * POST        → validates and updates the participant record
 *
 * Protected: admin login required.
 */

// ── Auth guard ────────────────────────────────────────────────
require 'auth_check.php';

// ── Database connection ───────────────────────────────────────
include 'dbconnect.php';

$adminName   = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');
$participant = null;
$errors      = [];
$formValues  = [];
$successMsg  = '';

// ─────────────────────────────────────────────────────────────
// POST: Process the submitted form and UPDATE the database
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve and sanitise inputs
    $id              = filter_input(INPUT_POST, 'id',               FILTER_VALIDATE_INT);
    $powerRaw        = trim($_POST['power_output']      ?? '');
    $distanceRaw     = trim($_POST['distance_travelled'] ?? '');

    // Keep form values for re-display if validation fails
    $formValues['power_output']       = $powerRaw;
    $formValues['distance_travelled'] = $distanceRaw;

    // ── Validate ID ───────────────────────────────────────────
    if (!$id || $id < 1) {
        $errors[] = 'Invalid participant ID.';
    }

    // ── Validate Power Output ─────────────────────────────────
    if ($powerRaw === '') {
        $errors[] = 'Power output is required.';
    } elseif (!is_numeric($powerRaw)) {
        $errors[] = 'Power output must be a number (e.g. 250.5).';
    } else {
        $powerVal = (float) $powerRaw;
        if ($powerVal < 0) {
            $errors[] = 'Power output cannot be negative.';
        } elseif ($powerVal > 9999) {
            $errors[] = 'Power output cannot exceed 9999 watts.';
        }
    }

    // ── Validate Distance ─────────────────────────────────────
    if ($distanceRaw === '') {
        $errors[] = 'Distance travelled is required.';
    } elseif (!is_numeric($distanceRaw)) {
        $errors[] = 'Distance must be a number (e.g. 42.5).';
    } else {
        $distVal = (float) $distanceRaw;
        if ($distVal < 0) {
            $errors[] = 'Distance cannot be negative.';
        } elseif ($distVal > 99999) {
            $errors[] = 'Distance cannot exceed 99999 km.';
        }
    }

    if (empty($errors)) {
        // ── Run the UPDATE query ──────────────────────────────
        try {
            // Fetch participant details so we can re-render the form
            $selectStmt = $conn->prepare(
                "SELECT p.id, p.firstname, p.surname, p.email, p.power_output, p.distance, c.name AS club_name
                 FROM participant p
                 LEFT JOIN club c ON p.club_id = c.id
                 WHERE p.id = :id LIMIT 1"
            );
            $selectStmt->execute([':id' => $id]);
            $participant = $selectStmt->fetch();

            if (!$participant) {
                $errors[] = 'Participant not found.';
            } else {
                // Only update power_output and distance — no other fields
                $updateStmt = $conn->prepare(
                    "UPDATE participant
                     SET power_output = :power, distance = :distance
                     WHERE id = :id"
                );
                $updateStmt->execute([
                    ':power'    => $powerVal,
                    ':distance' => $distVal,
                    ':id'       => $id,
                ]);

                // Refresh participant data to show updated values
                $participant['power_output'] = $powerVal;
                $participant['distance']     = $distVal;

                $successMsg = 'Scores updated successfully for ' .
                              htmlspecialchars($participant['firstname'] . ' ' . $participant['surname']) . '!';
            }

        } catch (PDOException $e) {
            error_log('Cit-E Cycling DB Error (edit_participant.php POST): ' . $e->getMessage());
            $errors[] = 'A database error occurred. Please try again.';
        }

    } else {
        // Re-fetch participant so we can re-render the form on validation failure
        if ($id && $id > 0) {
            try {
                $selectStmt = $conn->prepare(
                    "SELECT p.id, p.firstname, p.surname, p.email, p.power_output, p.distance, c.name AS club_name
                     FROM participant p
                     LEFT JOIN club c ON p.club_id = c.id
                     WHERE p.id = :id LIMIT 1"
                );
                $selectStmt->execute([':id' => $id]);
                $participant = $selectStmt->fetch();
            } catch (PDOException $e) {
                $errors[] = 'Could not reload participant data.';
            }
        }
    }

// ─────────────────────────────────────────────────────────────
// GET: Fetch the participant to pre-fill the form
// ─────────────────────────────────────────────────────────────
} else {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if (!$id || $id < 1) {
        // No valid ID supplied — redirect to the participants list
        header('Location: view_participants_edit_delete.php');
        exit();
    }

    try {
        $stmt = $conn->prepare(
            "SELECT p.id, p.firstname, p.surname, p.email, p.power_output, p.distance, c.name AS club_name
             FROM participant p
             LEFT JOIN club c ON p.club_id = c.id
             WHERE p.id = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $participant = $stmt->fetch();

        if (!$participant) {
            // Participant doesn't exist
            header('Location: view_participants_edit_delete.php?error=notfound');
            exit();
        }

    } catch (PDOException $e) {
        error_log('Cit-E Cycling DB Error (edit_participant.php GET): ' . $e->getMessage());
        $errors[] = 'Unable to load participant data. Please try again.';
    }
}

/**
 * For the brave souls who get this far: You are the chosen ones,
 * the valiant knights of programming who toil away, without rest,
 * fixing our most awful code. To you, true saviors, kings of men,
 * I say this: never gonna give you up, never gonna let you down,
 * never gonna run around and desert you. Never gonna make you cry,
 * never gonna say goodbye. Never gonna tell a lie and hurt you.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Participant — Cit-E Cycling Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="admin_menu.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="view_participants_edit_delete.php"><i class="fas fa-users me-1"></i> Participants</a></li>
                <li class="nav-item ms-lg-2"><span class="admin-badge d-none d-lg-inline"><i class="fas fa-user-shield me-1"></i> <?= $adminName ?></span></li>
                <li class="nav-item ms-lg-2"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="admin_menu.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="view_participants_edit_delete.php">Participants</a></li>
                <li class="breadcrumb-item active">Edit Scores</li>
            </ol>
        </nav>
        <h1><i class="fas fa-edit me-2"></i>EDIT PARTICIPANT SCORES</h1>
        <p class="mb-0" style="color:rgba(255,255,255,0.7);">Update power output and distance for this participant.</p>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-7">

                <!-- ── Success message ── -->
                <?php if ($successMsg): ?>
                <div class="alert alert-success mb-4">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= $successMsg ?>
                    <div class="mt-3 d-flex gap-2">
                        <a href="view_participants_edit_delete.php" class="btn btn-sm btn-racing">
                            <i class="fas fa-list me-1"></i> Back to All Participants
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <!-- ── General DB errors (no participant loaded) ── -->
                <?php if (!empty($errors) && !$participant): ?>
                <div class="alert alert-danger mb-4">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0 mt-1">
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <a href="view_participants_edit_delete.php" class="btn btn-dark-outline">
                    <i class="fas fa-arrow-left me-2"></i> Back to Participants
                </a>
                <?php endif; ?>

                <!-- ── Edit form (shown if participant loaded) ── -->
                <?php if ($participant): ?>
                <div class="card">
                    <div class="card-header-racing d-flex align-items-center gap-3">
                        <div class="icon"><i class="fas fa-edit"></i></div>
                        <h5>UPDATE SCORES</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php include 'edit_participant_form.php'; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Panel &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

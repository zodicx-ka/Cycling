<?php
/**
 * dbconnect.php
 * Database connection file for Cit-E Cycling
 *
 * SETUP: Fill in your database credentials below before running.
 * For XAMPP: username="root", password="", database="cycling"
 * For UoS webspace: use your assigned credentials
 */

// ── Database credentials ──────────────────────────────────────
$servername = "localhost";   // Usually "localhost" for XAMPP
$username   = "root";        // Your DB username (XAMPP default: root)
$password   = "";            // Your DB password (XAMPP default: empty)
$database   = "cycling";     // The database name

// ── Create PDO connection ─────────────────────────────────────
// We create $conn here so all included files can use it directly.
try {
    $conn = new PDO(
        "mysql:host=$servername;dbname=$database;charset=utf8",
        $username,
        $password
    );
    // Throw exceptions on errors (never silently fail)
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Return results as associative arrays by default
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    // Use real prepared statements (protects against SQL injection)
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
    // Show a friendly error — never expose raw PDO messages in production
    die('<div style="font-family:sans-serif;padding:2rem;background:#fee;border:1px solid #c00;border-radius:8px;max-width:500px;margin:3rem auto;">
            <strong>Database Connection Error</strong><br>
            Could not connect to the database. Please check your credentials in <code>dbconnect.php</code>.
            <br><small style="color:#888">Error: ' . htmlspecialchars($e->getMessage()) . '</small>
         </div>');
}
?>

<?php
/**
 * view_participants_edit_delete.php
 * Admin page — lists all participants with links to edit scores or delete.
 * Protected: admin login required.
 */

// ── Auth guard ────────────────────────────────────────────────
require 'auth_check.php';

// ── Database connection ───────────────────────────────────────
include 'dbconnect.php';

// ── Fetch all participants with their club name ───────────────
$participants = [];
$fetchError   = '';

try {
    // JOIN participant with club to show the club name alongside each rider
    $stmt = $conn->prepare(
        "SELECT p.id, p.firstname, p.surname, p.email,
                p.power_output, p.distance,
                c.name AS club_name
         FROM participant p
         LEFT JOIN club c ON p.club_id = c.id
         ORDER BY p.surname ASC, p.firstname ASC"
    );
    $stmt->execute();
    $participants = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log('Cit-E Cycling DB Error (view_participants_edit_delete.php): ' . $e->getMessage());
    $fetchError = 'Unable to load participants. Please try again.';
}

$adminName = htmlspecialchars($_SESSION['admin_username'] ?? 'Admin');
$count     = count($participants);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Participants — Cit-E Cycling Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<!-- ── Navbar ──────────────────────────────────────────────────── -->
<nav class="navbar navbar-expand-lg navbar-cycling">
    <div class="container">
        <a class="navbar-brand" href="index.html">
            <div class="brand-icon"><i class="fas fa-bicycle"></i></div>
            CIT-E CYCLING
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="nav-link" href="admin_menu.php"><i class="fas fa-tachometer-alt me-1"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="search_form.php"><i class="fas fa-search me-1"></i> Search</a></li>
                <li class="nav-item"><a class="nav-link active" href="view_participants_edit_delete.php"><i class="fas fa-users me-1"></i> Participants</a></li>
                <li class="nav-item ms-lg-2"><span class="admin-badge d-none d-lg-inline"><i class="fas fa-user-shield me-1"></i> <?= $adminName ?></span></li>
                <li class="nav-item ms-lg-2"><a class="nav-link" href="logout.php" onclick="return confirmLogout();"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ── Page Header ─────────────────────────────────────────────── -->
<div class="page-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="admin_menu.php">Dashboard</a></li>
                <li class="breadcrumb-item active">All Participants</li>
            </ol>
        </nav>
        <h1><i class="fas fa-users me-2"></i>ALL PARTICIPANTS</h1>
        <p class="mb-0" style="color:rgba(255,255,255,0.7);">
            <?= $count ?> participants registered &mdash; click Edit or Delete to manage entries.
        </p>
    </div>
</div>

<!-- ── Main Content ─────────────────────────────────────────────── -->
<main class="main-content">
    <div class="container">

        <!-- ── Errors ── -->
        <?php if ($fetchError): ?>
            <div class="alert alert-danger mb-4">
                <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($fetchError) ?>
            </div>
        <?php endif; ?>

        <!-- ── Toolbar ── -->
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
            <div>
                <input type="text" id="tableSearch" class="form-control"
                       placeholder="&#128269; Filter by name, email, or club..."
                       style="width:280px;" oninput="filterTable()">
            </div>
            <div class="d-flex gap-2">
                <a href="search_form.php" class="btn btn-dark-outline btn-sm">
                    <i class="fas fa-search me-1"></i> Advanced Search
                </a>
                <a href="admin_menu.php" class="btn btn-dark-outline btn-sm">
                    <i class="fas fa-arrow-left me-1"></i> Dashboard
                </a>
            </div>
        </div>

        <!-- ── Participants Table ── -->
        <?php if (empty($participants) && !$fetchError): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                No participants found in the database.
            </div>
        <?php elseif (!empty($participants)): ?>
            <div class="card">
                <div class="card-header-racing d-flex align-items-center gap-3">
                    <div class="icon"><i class="fas fa-table"></i></div>
                    <h5>PARTICIPANT RECORDS</h5>
                    <span class="ms-auto badge bg-secondary"><?= $count ?> total</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-cycling mb-0" id="participantsTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Club</th>
                                <th>Power (W)</th>
                                <th>Distance (km)</th>
                                <th style="text-align:center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($participants as $i => $p): ?>
                            <tr>
                                <td><span class="text-muted" style="font-size:0.82rem;"><?= (int)$p['id'] ?></span></td>
                                <td>
                                    <div style="font-weight:700; font-size:0.92rem;">
                                        <?= htmlspecialchars($p['firstname'] . ' ' . $p['surname']) ?>
                                    </div>
                                </td>
                                <td>
                                    <a href="mailto:<?= htmlspecialchars($p['email']) ?>" style="font-size:0.85rem; color:var(--muted);">
                                        <?= htmlspecialchars($p['email']) ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($p['club_name']): ?>
                                        <span class="badge-club"><?= htmlspecialchars($p['club_name']) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted" style="font-size:0.82rem;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge-stat"><?= number_format((float)$p['power_output'], 1) ?> W</span>
                                </td>
                                <td>
                                    <span class="badge-stat" style="background:linear-gradient(135deg,#2ecc71,#27ae60);">
                                        <?= number_format((float)$p['distance'], 2) ?> km
                                    </span>
                                </td>
                                <td style="text-align:center; white-space:nowrap;">
                                    <!-- Edit link — passes participant ID -->
                                    <a href="edit_participant.php?id=<?= (int)$p['id'] ?>"
                                       class="btn btn-sm btn-warning btn-sm-racing me-1"
                                       title="Edit scores for <?= htmlspecialchars($p['firstname']) ?>">
                                        <i class="fas fa-edit me-1"></i> Edit
                                    </a>
                                    <!-- Delete link — passes participant ID -->
                                    <a href="delete.php?id=<?= (int)$p['id'] ?>"
                                       class="btn btn-sm btn-danger btn-sm-racing"
                                       title="Delete <?= htmlspecialchars($p['firstname']) ?>"
                                       onclick="return confirmDelete('<?= htmlspecialchars($p['firstname'] . ' ' . $p['surname'], ENT_QUOTES) ?>')">
                                        <i class="fas fa-trash me-1"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

    </div>
</main>

<footer>
    <strong>Cit-E Cycling</strong> &mdash; Admin Panel &mdash; &copy; 2024
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    /** Quick client-side filter for the participants table */
    function filterTable() {
        const query = document.getElementById('tableSearch').value.toLowerCase();
        const rows  = document.querySelectorAll('#participantsTable tbody tr');
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(query) ? '' : 'none';
        });
    }

    /** Pre-delete confirmation with the participant's name */
    function confirmDelete(name) {
        return confirm(`Are you sure you want to permanently delete "${name}"?\n\nThis action cannot be undone.`);
    }

    function confirmLogout() {
        return confirm('Are you sure you want to logout?');
    }
</script>
</body>
</html>
